// TODO: replace if yours are different
module.exports = {
    accountName: 'letpat-cosmos1-db',
    databaseName: 'admin',
    key: 'lC51ZPEdSKSVALQFFIBjSgghbKAQVvFNr6MpEb3coQwjZm2wEayiAEeWZbXm13zhndDIwRb2U4qVgNpLEemwkA%3D%3D',
    port: 10255
};